export { NavbarHireTalent } from "./NavbarHireTalent";
