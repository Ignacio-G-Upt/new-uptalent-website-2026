export { IconRelume } from "./IconRelume";
