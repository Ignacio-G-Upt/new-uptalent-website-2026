import { SizeSmallHierarchyWrapper } from ".";

export default {
  title: "Components/SizeSmallHierarchyWrapper",
  component: SizeSmallHierarchyWrapper,
};

export const Default = {
  args: {
    className: {},
  },
};
