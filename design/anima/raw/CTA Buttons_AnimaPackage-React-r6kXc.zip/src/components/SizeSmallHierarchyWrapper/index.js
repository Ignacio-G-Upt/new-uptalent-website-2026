export { SizeSmallHierarchyWrapper } from "./SizeSmallHierarchyWrapper";
