import { SizeBigHierarchyWrapper } from ".";

export default {
  title: "Components/SizeBigHierarchyWrapper",
  component: SizeBigHierarchyWrapper,
};

export const Default = {
  args: {
    className: {},
  },
};
