export { SizeBigHierarchySecondaryStrokeStateHover } from "./SizeBigHierarchySecondaryStrokeStateHover";
