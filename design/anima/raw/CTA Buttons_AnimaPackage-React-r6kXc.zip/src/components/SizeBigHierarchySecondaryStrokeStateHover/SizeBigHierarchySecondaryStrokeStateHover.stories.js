import { SizeBigHierarchySecondaryStrokeStateHover } from ".";

export default {
  title: "Components/SizeBigHierarchySecondaryStrokeStateHover",
  component: SizeBigHierarchySecondaryStrokeStateHover,
};

export const Default = {
  args: {
    className: {},
  },
};
