export { SizeSmallHierarchySecondaryStrokeStateHover } from "./SizeSmallHierarchySecondaryStrokeStateHover";
