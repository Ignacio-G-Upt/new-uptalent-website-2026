import { SizeSmallHierarchySecondaryStrokeStateHover } from ".";

export default {
  title: "Components/SizeSmallHierarchySecondaryStrokeStateHover",
  component: SizeSmallHierarchySecondaryStrokeStateHover,
};

export const Default = {
  args: {
    className: {},
  },
};
