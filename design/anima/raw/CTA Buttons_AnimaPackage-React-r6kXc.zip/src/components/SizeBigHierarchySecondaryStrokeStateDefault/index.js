export { SizeBigHierarchySecondaryStrokeStateDefault } from "./SizeBigHierarchySecondaryStrokeStateDefault";
