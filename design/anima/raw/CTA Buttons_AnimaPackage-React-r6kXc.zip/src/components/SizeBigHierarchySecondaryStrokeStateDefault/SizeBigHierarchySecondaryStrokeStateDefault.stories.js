import { SizeBigHierarchySecondaryStrokeStateDefault } from ".";

export default {
  title: "Components/SizeBigHierarchySecondaryStrokeStateDefault",
  component: SizeBigHierarchySecondaryStrokeStateDefault,
};

export const Default = {
  args: {
    className: {},
  },
};
