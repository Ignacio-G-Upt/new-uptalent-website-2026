export { SizeSmallHierarchy } from "./SizeSmallHierarchy";
