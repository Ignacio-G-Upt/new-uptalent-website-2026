import { SizeSmallHierarchy } from ".";

export default {
  title: "Components/SizeSmallHierarchy",
  component: SizeSmallHierarchy,
};

export const Default = {
  args: {
    className: {},
  },
};
