import { SizeBigHierarchy } from ".";

export default {
  title: "Components/SizeBigHierarchy",
  component: SizeBigHierarchy,
};

export const Default = {
  args: {
    className: {},
    text: "Button CTA",
  },
};
