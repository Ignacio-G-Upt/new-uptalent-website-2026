export { CardTalent } from "./CardTalent";
