export { AccordionFaqs } from "./AccordionFaqs";
