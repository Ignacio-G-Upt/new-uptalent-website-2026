export { ButtonsBigTertiary } from "./ButtonsBigTertiary";
