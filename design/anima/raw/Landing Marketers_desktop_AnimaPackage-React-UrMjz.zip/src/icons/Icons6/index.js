export { Icons6 } from "./Icons6";
