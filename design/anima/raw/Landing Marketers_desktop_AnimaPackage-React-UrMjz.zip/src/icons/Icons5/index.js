export { Icons5 } from "./Icons5";
