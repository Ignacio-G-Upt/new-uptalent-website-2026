export { Property1AiUser } from "./Property1AiUser";
