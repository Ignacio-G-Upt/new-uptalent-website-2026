export { Property1ChileCl } from "./Property1ChileCl";
