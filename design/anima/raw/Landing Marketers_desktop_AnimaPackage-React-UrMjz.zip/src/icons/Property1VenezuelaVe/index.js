export { Property1VenezuelaVe } from "./Property1VenezuelaVe";
