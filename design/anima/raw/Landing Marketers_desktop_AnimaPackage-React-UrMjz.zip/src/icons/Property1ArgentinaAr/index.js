export { Property1ArgentinaAr } from "./Property1ArgentinaAr";
