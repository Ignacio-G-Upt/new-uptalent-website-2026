export { Icons8 } from "./Icons8";
