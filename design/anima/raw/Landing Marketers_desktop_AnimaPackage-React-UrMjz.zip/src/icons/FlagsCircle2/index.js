export { FlagsCircle2 } from "./FlagsCircle2";
