export { Icons3 } from "./Icons3";
