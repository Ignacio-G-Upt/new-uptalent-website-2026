export { Property1WalletDone02 } from "./Property1WalletDone02";
