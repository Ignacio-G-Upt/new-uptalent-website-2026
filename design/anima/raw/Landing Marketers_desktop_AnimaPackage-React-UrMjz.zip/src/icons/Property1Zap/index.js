export { Property1Zap } from "./Property1Zap";
