export { FlagsCircle10 } from "./FlagsCircle10";
