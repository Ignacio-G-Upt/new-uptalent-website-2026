export { Icons2 } from "./Icons2";
