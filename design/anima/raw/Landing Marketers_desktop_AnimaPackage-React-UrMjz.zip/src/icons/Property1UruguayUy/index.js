export { Property1UruguayUy } from "./Property1UruguayUy";
