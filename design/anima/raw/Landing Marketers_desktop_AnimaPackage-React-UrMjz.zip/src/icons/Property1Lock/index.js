export { Property1Lock } from "./Property1Lock";
