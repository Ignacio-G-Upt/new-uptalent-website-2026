export { Property1ColombiaCo } from "./Property1ColombiaCo";
