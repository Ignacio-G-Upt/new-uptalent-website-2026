export { Property1MexicoMx } from "./Property1MexicoMx";
