export { Property1BrazilBr } from "./Property1BrazilBr";
