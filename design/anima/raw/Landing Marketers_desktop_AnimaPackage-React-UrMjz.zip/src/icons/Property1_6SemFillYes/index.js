export { Property1_6SemFillYes } from "./Property1_6SemFillYes";
