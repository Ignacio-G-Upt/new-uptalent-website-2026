export { Property1PeruPe } from "./Property1PeruPe";
