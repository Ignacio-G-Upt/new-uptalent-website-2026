import React from "react";

export const Box = () => {
  return (
    <div className="w-[2648px] h-[2229px]" data-model-id="2244:4271-frame">
      <img
        className="fixed w-[2648px] h-[2229px] top-0 left-0"
        alt="Typography"
        src="/img/typography.svg"
      />
    </div>
  );
};
