export { Icon24 } from "./Icon24";
