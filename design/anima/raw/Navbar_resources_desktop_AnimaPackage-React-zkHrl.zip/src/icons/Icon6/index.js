export { Icon6 } from "./Icon6";
